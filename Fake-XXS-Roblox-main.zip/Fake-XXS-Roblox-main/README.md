# Fake-XSS-Roblox
- Made this to show how easy it is to fake a XSS Method, when it does not exist. Many people get scammed everyday trying to buy this method. 

# How The Logs Look Like:
- https://media.discordapp.net/attachments/996764426201997312/997073638341742653/unknown.png

# Setup.
- Go To The Code, You Will See A List Like This ["4kByron", "Builderman", "Roblox"], replace the usernames that you want to fake-log
- Put Your Webhook In Strings Where It Says You To Put It.
- Recommended to run this code at https://repl.it because you get a nice little link there aswell.

# This Is Fake, Do Not Expect It To Work.
